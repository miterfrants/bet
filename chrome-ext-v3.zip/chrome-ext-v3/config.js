const env = 'prod'; // dev or prod
const apiEndPoint = env === 'dev' ? 'https://dev.bet.homo.tw:5001/api/v1' : 'https://bet.homo.tw/api/v1';
export const RESPONSE_STATUS = {
    OK: 'OK',
    FAILED: 'FAILED'
};
export const API = {
    ENDPOINT: apiEndPoint,
    AUTH: apiEndPoint + '/auth/auth-from-chrome-ext',
    COINS_EARN: apiEndPoint + '/coins/earn',
    COINS_BET: apiEndPoint + '/coins/bet',
    SHAREHOLDING: apiEndPoint + '/rewards/shareholding',
    COINS_PER_WEEK: apiEndPoint + '/rewards/coins-per-week',
    USERS: apiEndPoint + '/chrome-extension/users'
};
